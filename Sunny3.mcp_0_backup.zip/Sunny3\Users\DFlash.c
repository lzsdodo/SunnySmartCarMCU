#include "DFlash.h"

void EEPROM_SetFloat(EEPROM_TAddress Addr,float Data)
{
  union
  {
    float Temp_Data;
    dword Data_Part;
  }_Float_;
  _Float_.Temp_Data = Data;
  while(EEPROM_SetLong( Addr ,_Float_.Data_Part));

}

float EEPROM_GetFloat(EEPROM_TAddress Addr)
{
  union
  {
    float Temp_Data;
    dword Data_Part;
  }_Float_;
  
  while(EEPROM_GetLong( Addr ,&_Float_.Data_Part));
  return _Float_.Temp_Data;
  
}
//*---�������ݵ�DFlash---*//
void DFSaveData(void)
{
    EEPROM_SetFloat( EEPROM_AREA_START   , fAngleKp);
    EEPROM_SetFloat( EEPROM_AREA_START+4 , fAngleKd);
    EEPROM_SetFloat( EEPROM_AREA_START+8 , fSpeedKp);
    EEPROM_SetFloat( EEPROM_AREA_START+12, fSpeedKi);
    EEPROM_SetFloat( EEPROM_AREA_START+16, fDirKp);
    EEPROM_SetFloat( EEPROM_AREA_START+20, fDirKd);
    EEPROM_SetFloat( EEPROM_AREA_START+24, fAngleOffSet); 

}
//*---�������ݵ�DFlash---*//

//*---��ȡDFlash������---*//
void DFReadData(void)
{
    fAngleKp = EEPROM_GetFloat(EEPROM_AREA_START);
    fAngleKd = EEPROM_GetFloat(EEPROM_AREA_START+4);
    fSpeedKp = EEPROM_GetFloat(EEPROM_AREA_START+8);
    fSpeedKi = EEPROM_GetFloat(EEPROM_AREA_START+12);
    fDirKp   = EEPROM_GetFloat(EEPROM_AREA_START+16);
    fDirKd   = EEPROM_GetFloat(EEPROM_AREA_START+20);
    fAngleOffSet = EEPROM_GetFloat(EEPROM_AREA_START+24);
}
//*---��ȡDFlash������---*//

