#ifndef _DFlash_H_
#define _DFlash_H_

#include "EEPROM.h"

extern long int DFStrAddr; // 0x101C00

extern float fAngleKp;
extern float fAngleKd;
extern float fSpeedKp;
extern float fSpeedKi;
extern float fDirKp;
extern float fDirKd;
extern float fAngleOffSet;

static EEPROM_SetFloat(EEPROM_TAddress Addr,float Data);
static float EEPROM_GetFloat(EEPROM_TAddress Addr);
void DFSaveData(void);
void DFReadData(void);


#endif  /* _DFlash_H_ */