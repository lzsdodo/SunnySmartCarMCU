#include "MotPID.h"

//********************�����ʼ��********************
void  Mot_Init(void)
{
    //����˿ڳ�ʼ��
    //PTT_PTT*=0/1;PTP_PTP*=0/1;
        //����
    DDRT_DDRT2=1;       //MotorLeftDirSet_SetDir(1);Output
    DDRT_DDRT0=0;       //MotorLeftDirReal_SetDir(0);Input
    DDRT_DDRT1=1;       //MotorLeftCounterSelect_SetDir(1);Output
    PTT_PTT1=1;         //MotorLeftCounterSelect_ClrVal();  
        //�ҵ��
    DDRP_DDRP3=1;       //MotorRightDirSet_SetDir(1);Output
    DDRT_DDRT3=0;       //MotorRightDirReal_SetDir(0);Input
    DDRP_DDRP2=1;       //MotorRightCounterSelect_SetDir(1);Output
    PTP_PTP2=1;         //MotorRightCounterSelect_SetVal();
    //�ٶȳ�ʼ��Ϊ0
    Mot_SetLefPWM(0,0,0);
    Mot_SetRigPWM(0,0,0);

}
//********************����ٶ��趨********************
void Mot_SetLefPWM(float AngleOut,float SpeedOut,float DirOut) //��77us ִ��1��39us  
{   
    long int AllOut = 0;
    
    //����ٶ�����
    AllOut = (long int)((AngleOut - SpeedOut + DirOut) * 10 );
    
    if( AllOut >= 0 ) 
    {
        AllOut += 1500;      //DeadlinePWM=1500   
        if( AllOut > 65535 )  AllOut = 65535; 
        PTT_PTT2 = 1;//��ת
        while(MotLefPWM_SetRatio16(AllOut)); 
    }
    else              
    {
        AllOut += 64035;    //-1500 +65535
        if( AllOut < 0 )    AllOut = 0;
        PTT_PTT2 = 0;//��ת
        while(MotLefPWM_SetRatio16(AllOut));
    } 
}

void Mot_SetRigPWM(float AngleOut,float SpeedOut,float DirOut) //��77us ִ��1��39us  
{   
    long int AllOut = 0;
    
    //����ٶ�����
    AllOut = (long int)((AngleOut - SpeedOut - DirOut) * 10 );
    
    if( AllOut >= 0 ) 
    {
        AllOut += 1500;      //DeadlinePWM=1500   
        if( AllOut > 65535 )  AllOut = 65535; 
        PTP_PTP3 = 1;//��ת
        while(MotRigPWM_SetRatio16(AllOut));
    }
    else              
    {
        AllOut += 64035;    //-1500 +65535
        if( AllOut < 0 )    AllOut = 0;
        PTP_PTP3 = 0;//��ת
        while(MotRigPWM_SetRatio16(AllOut));
    } 
}
  

//******************������ƺ���****************************************
void Speed_RealCal(bool Which) //2us 
{
    word Pulse;
    Pulse = PACNT;            //T7�ڶ�ȡ������,��ȡ���ת��
    PACNT = 0;
    switch(Which) 
    { 
      case 0://��������
        {     
          //��ȡ�������ʱ���û�ȡ�ҵ��ת��
          PTT_PTT1 = 1;       //MotorLeftCounterSelect_SetVal();
          PTP_PTP2 = 0;       //MotorRightCounterSelect_ClrVal();
          PACNT    = 0;       //PulsCounter_ResetCounter();  
          //ת���ȡ������������ʵ���ٶ�ֵ
          if(PTT_PTT0 == 1) nSpeedLef = (-1 * Pulse); //MotorLeftDirReal_GetVal() 
          else              nSpeedLef = Pulse;
          break;
        }
      default://�ҵ������
        {
          //��ȡ�ҵ�����ʱ���û�ȡ����ת��
          PTP_PTP2 = 1;       //MotorRightCounterSelect_SetVal();
          PTT_PTT1 = 0;       //MotorLeftCounterSelect_ClrVal();
          PACNT    = 0;       //PulsCounter_ResetCounter(); 
          //ת���ȡ������������ʵ���ٶ�ֵ
          if(PTT_PTT3 == 1) nSpeedRig = Pulse;//MotorRightDirReal_GetVal()
          else              nSpeedRig = (-1 * Pulse);  
          break;
        }    
    }
    nSpeedAvr = nSpeedLef + nSpeedRig;  
}

void Speed_PID(void)//44us 
{
    float SpeedTmp1;
    float SpeedTmp2;
    int   SpeedEKOld;
    int   SpeedEKDelta;
    
    //PID�㷨���� 
    SpeedEKOld   = nSpeedEK;
    nSpeedEK     = nSpeedSet - nSpeedAvr;
    //����
    if(nSpeedEK > 32)        nSpeedEK = 32;
    else if(nSpeedEK < -32)  nSpeedEK = -32;
    SpeedEKDelta = nSpeedEK  - SpeedEKOld;
    
    
    //*************λ��ʽPID*************
    //����Kp=55;Ki=2; 
    //SpeedTmp1 = fSpeedKp * nSpeedEK;
    //if(SpeedTmp1>1000)     SpeedTmp1 = 1000;
    //else if(SpeedTmp1<-1000)  SpeedTmp1 = -1000;    
    //fSpeedIntergral += fSpeedKi * nSpeedEK;
    //if(fSpeedIntergral>1000)       fSpeedIntergral = 1000;
    //else if(fSpeedIntergral<-1000) fSpeedIntergral = -1000;
    //fSpeedOutSuperp=( SpeedTmp1 + fSpeedIntergral - fSpeedOut )/10.0;

    //*************����ʽPID*************
    //fSpeedOutSuperp =(fSpeedKp*nSpeedEKDelta + fSpeedKi*nSpeedEK)/10.0;
    SpeedTmp1 = fSpeedKp * SpeedEKDelta;
    SpeedTmp2 = fSpeedKi * nSpeedEK; 
    fSpeedOutSuperp = (SpeedTmp1 + SpeedTmp2) / 10.0;

  }
 
void Dir_PID(void)     //���������Ҹ�
{
    float DirTmp1;
    float DirTmp2;
    //fDirSuperp = fDirKp*fDirection - fDirKd*fYAngleSpeed;  
    DirTmp1 = fDirKp * fDir;
    DirTmp2 = fDirKd * fYAngleSpeedSum;
    fYAngleSpeedSum = 0;
    fDirOut  = ( DirTmp1 - DirTmp2 ) / 12;        // 6*5msFlg = 1ImaFlg /6; ���Ҿ��� /2; --/12
    
}

