#include "chuankou.h"

void SCISendInt(int pnum)
{

 /**/
    if(pnum<0)
    {
      pnum = -pnum;
      while(SCI_SendChar('-'));
    } 

    if(pnum<10)
    {
        while(SCI_SendChar(pnum+'0'));
    }
    else 
    {
        if(pnum<=999)
        {
            while(SCI_SendChar((unsigned char)(pnum/100+'0')));
            while(SCI_SendChar((unsigned char)(pnum/10%10+'0')));
            while(SCI_SendChar((unsigned char)(pnum%10+'0')));
        } 
        else
        {
            if(pnum<=9999)
            {
                while(SCI_SendChar(pnum/1000+'0'));
                while(SCI_SendChar(pnum/100%10+'0'));
                while(SCI_SendChar(pnum/10%10+'0'));
                while(SCI_SendChar(pnum%10+'0'));  
            } 
            else
            {
                while(SCI_SendChar(pnum/10000+48));
                while(SCI_SendChar(pnum/1000%10+48));
                while(SCI_SendChar(pnum/100%10+48));
                while(SCI_SendChar(pnum/10%10+48)); 
                while(SCI_SendChar(pnum%10+48));  
            }
        }
    }
}

void SCI_Send(int real,int set,int other) 
{
	/*=======���㷨�޹أ�Ϊ���ڴ����п����ݶ���������=======================*/
	/*====================SCI=====================*/
	while(SCI_SendChar('I'));
	SCISendInt((int)(real));						//red
	while(SCI_SendChar('|'));
	SCISendInt((int)(set));	 				//blue
	while(SCI_SendChar('|'));
	SCISendInt((int)(other));	   					//light blue
	while(SCI_SendChar('\r'));
	while(SCI_SendChar('\n'));      
}
